package com.panaceasoft.pscity.di;

/**
 * Created by Panacea-Soft on 11/15/17.
 * Contact Email : teamps.is.cool@gmail.com
 */

public interface Injectable {}
