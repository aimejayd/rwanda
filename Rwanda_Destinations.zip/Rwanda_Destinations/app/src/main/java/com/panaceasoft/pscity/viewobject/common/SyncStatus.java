package com.panaceasoft.pscity.viewobject.common;

/**
 * Created by Panacea-Soft on 12/12/17.
 * Contact Email : teamps.is.cool@gmail.com
 */

public class SyncStatus {
    public static final String SERVER_SELECTED = "1";
    public static final String SERVER_NOT_SELECTED = "0";
    public static final String LOCAL_SELECTED = "1";
    public static final String LOCAL_NOT_SELECTED  = "0";
}
