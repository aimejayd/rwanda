package com.panaceasoft.pscity.viewobject.holder;

import com.panaceasoft.pscity.utils.Constants;

import java.io.Serializable;

public class ItemParameterHolder implements Serializable {

    public String keyword, cat_id, sub_cat_id, order_by, order_type, rating_value, is_featured, is_promotion, lat, lng, miles;

    public ItemParameterHolder() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.order_by = Constants.FILTERING_ADDED_DATE;
        this.order_type = Constants.FILTERING_DESC;
        this.rating_value = "";
        this.is_featured = "";
        this.is_promotion = "";
        this.lat = "";
        this.lng = "";
        this.miles = "";

    }

    public ItemParameterHolder getFeaturedItem() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.order_by = Constants.FILTERING_FEATURE;
        this.order_type = Constants.FILTERING_DESC;
        this.rating_value = "";
        this.is_featured = Constants.ONE;
        this.is_promotion = "";
        this.lat = "";
        this.lng = "";
        this.miles = "";


        return this;
    }

    public ItemParameterHolder getDiscountItem() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.order_by = Constants.FILTERING_ADDED_DATE;
        this.order_type = Constants.FILTERING_DESC;
        this.rating_value = "";
        this.is_featured = "";
        this.is_promotion = Constants.ONE;
        this.lat = "";
        this.lng = "";
        this.miles = "";

        return this;
    }

    public ItemParameterHolder getPopularItem() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.order_by = Constants.FILTERING_TRENDING;
        this.order_type = Constants.FILTERING_DESC;
        this.rating_value = "";
        this.is_featured = "";
        this.is_promotion = "";
        this.lat = "";
        this.lng = "";
        this.miles = "";

        return this;
    }

    public ItemParameterHolder getRecentItem() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.order_by = Constants.FILTERING_ADDED_DATE;
        this.order_type = Constants.FILTERING_DESC;
        this.rating_value = "";
        this.is_featured = "";
        this.is_promotion = "";
        this.lat = "";
        this.lng = "";
        this.miles = "";

        return this;
    }

    public void resetTheHolder() {
        this.keyword = "";
        this.cat_id = "";
        this.sub_cat_id = "";
        this.is_featured = "";
        this.is_promotion = "";
        this.order_by = Constants.FILTERING_ADDED_DATE;
        this.order_type = Constants.FILTERING_DESC;
        this.lat = "";
        this.lng = "";
        this.miles = "";

    }

    public String getItemMapKey() {

        final String promotion = "promotion";
        final String featured = "featured";
        final String ratingValue = "rating_value";

        String result = "";

        if (!keyword.isEmpty()) {
            result += keyword + ":";
        }

        if (!cat_id.isEmpty()) {
            result += cat_id + ":";
        }

        if (!sub_cat_id.isEmpty()) {
            result += sub_cat_id + ":";
        }

        if (!order_by.isEmpty()) {
            result += order_by + ":";
        }

        if (!order_type.isEmpty()) {
            result += order_type + ":";
        }

        if (!rating_value.isEmpty()) {
            result += ratingValue + ":";
        }

        if (!is_featured.isEmpty()) {
            result += featured + ":";
        }

        if (!is_promotion.isEmpty()) {
            result += promotion + ":";
        }

        if (!lat.isEmpty()) {
            result += lat + ":";
        }

        if (!lng.isEmpty()) {
            result += lng + ":";
        }

        if (!miles.isEmpty()) {
            result += miles + ":";
        }

        return result;
    }
}
