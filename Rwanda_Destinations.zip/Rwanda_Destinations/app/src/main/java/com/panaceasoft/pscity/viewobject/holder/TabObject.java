package com.panaceasoft.pscity.viewobject.holder;

public class TabObject {
    public String field_name;

    public String tag_id;

    public String tag_name;

    public TabObject(String field_name,String tag_id,String tag_name) {
        this.field_name = field_name;
        this.tag_id = tag_id;
        this.tag_name = tag_name;
    }
}
